
<?php $__env->startSection('title', 'Edit Student'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
		
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
	<div class="col-lg-6">
		<form id='update_frm' method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="card">
				<div class="card-header bg-secondary text-white font-weight-bold">
					Edit Download Form
				</div>
				<div class="card-body"> 
					<div class='row'>
						<div class="col-md-12">
							
							<!-- <div class="form-group mb-3">
                                <label>Select Page</label>
                                <select class="form-select select2" name='download_name' required>
                                    <option value='' disabled>-- Select Page --</option>
                                    <option value='Franchisee Form' <?php echo e($download->download_name == 'Franchisee Form' ? 'selected' : ''); ?>>Franchisee Form</option>
                                    <option value='Admission Form' <?php echo e($download->download_name == 'Admission Form' ? 'selected' : ''); ?>>Admission Form</option>
                                    <option value='Company Certificate' <?php echo e($download->download_name == 'Company Certificate' ? 'selected' : ''); ?>>Company Certificate</option>
                                    <option value='Company PAN Card' <?php echo e($download->download_name == 'Company PAN Card' ? 'selected' : ''); ?>>Company PAN Card</option>
                                    <option value='Udyam Registration Certificate' <?php echo e($download->download_name == 'Udyam Registration Certificate' ? 'selected' : ''); ?>>Udyam Registration Certificate</option>
                                    <option value='Startup India Certificate' <?php echo e($download->download_name == 'Startup India Certificate' ? 'selected' : ''); ?>>Startup India Certificate</option>
                                    <option value='ISO Certificate' <?php echo e($download->download_name == 'ISO Certificate' ? 'selected' : ''); ?>>ISO Certificate</option>
                                    <option value='Trademark Certificate' <?php echo e($download->download_name == 'Trademark Certificate' ? 'selected' : ''); ?>>Trademark Certificate</option>
                                </select>
                            </div> -->

                            <div class="form-group mb-3">
								<label>Name</label>
								<input type="text" name="download_name" value="<?php echo e($download->download_name??''); ?>" id="download_name" class="form-control" placeholder="Name">
							</div>

							<div class="form-group mb-3 ">
								<label>Slug</label>
								<input type="text" name="slug" id="slug" value="<?php echo e($download->slug??''); ?>" class="form-control" placeholder="Slug" readonly>
							</div>

                            <div class="form-group mb-3">
                                <label>Download Type</label>
                                <select class="form-select" name="type" required>
                                    <option value='' disabled>-- Select Type --</option>
                                    <option value='View' <?php echo e($download->type == 'View' ? 'selected' : ''); ?>>View</option>
                                    <option value='Download' <?php echo e($download->type == 'Download' ? 'selected' : ''); ?>>Download</option>
                                </select>
                            </div>

                            <div class="form-group mb-3">
                                <label>Upload File</label><br>
                                <input class="form-control" type='file' name='file' accept='.pdf,.doc,.docx,.jpg,.png,.jpeg'>
                                <?php if($download->file): ?>
                                    <small class="text-muted">
                                        Current File: 
                                        <a href="<?php echo e(asset('storage/'.$download->file)); ?>" target="_blank"><?php echo e($download->file); ?></a>
                                    </small>
                                <?php endif; ?>
                            </div>

						</div>
					</div>
				</div>

				
				<div class="card-footer bg-light text-right">
					<a href="<?php echo e(route('student_list')); ?>" class="btn btn-dark btn-sm">View All</a>
					<button type="submit" class="btn btn-success btn-sm" id="update_btn" accesskey="s">Save</button>
				</div>

			</div>
		</form>
	</div>
</div>
<script>
		document.getElementById('download_name').addEventListener('keyup', function () {
			let name = this.value;
			let slug = name.toLowerCase()
						.replace(/[^a-z0-9]+/g, '-')  // replace non-alphanumeric with -
						.replace(/^-+|-+$/g, '');     // remove starting/ending -  
			document.getElementById('slug').value = slug;
		});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\mayacomputer\resources\views/admin/cms/downloads/edit.blade.php ENDPATH**/ ?>