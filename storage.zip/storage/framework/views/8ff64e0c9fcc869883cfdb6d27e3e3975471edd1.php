
<?php $__env->startSection('title','Download Doocument'); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-4 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card shadow-sm border-0">
                <div class="card-body p-3">

                    <iframe src="<?php echo e(asset($data->file)); ?>" 
                        width="100%" 
                        height="800px"
                        style="border: none;">
                    </iframe>

                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\mayacomputer\resources\views/frontend/download-document.blade.php ENDPATH**/ ?>