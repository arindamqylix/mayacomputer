
<?php $__env->startSection('title', 'Site Settings'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
    .preview-img {
        max-width: 120px;
        border: 1px solid #ddd;
        border-radius: 6px;
        padding: 4px;
        margin-top: 8px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-lg-8">
        <form id="update_frm" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header bg-secondary text-white font-weight-bold">
                    Site Settings
                </div>
                <div class="card-body"> 
                    <div class="row">
                        <div class="col-md-12">

                            <div class="form-group mb-3">
                                <label>Site Name</label>
                                <input type="text" name="name" value="<?php echo e($setting->name ?? ''); ?>" class="form-control" required>
                            </div>

                            <div class="form-group mb-3">
                                <label>Email</label>
                                <input type="email" name="email" value="<?php echo e($setting->email ?? ''); ?>" class="form-control" required>
                            </div>

                            <div class="form-group mb-3">
                                <label>Phone</label>
                                <input type="text" name="phone" value="<?php echo e($setting->phone ?? ''); ?>" class="form-control" required>
                            </div>

                            <div class="form-group mb-3">
                                <label>Address</label>
                                <textarea name="address" class="form-control" rows="2" required><?php echo e($setting->address ?? ''); ?></textarea>
                            </div>

                            <div class="form-group mb-3">
                                <label>Site Logo</label>
                                <input type="file" class="form-control" name="site_logo" accept=".jpg,.jpeg,.png,.gif">
                                <?php if(!empty($setting->site_logo)): ?>
                                    <div class="mt-2">
                                        <label class="text-muted">Current Logo:</label><br>
                                        <img src="<?php echo e(asset('storage/'.$setting->site_logo)); ?>" alt="Site Logo" class="preview-img">
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <label>Site Favicon</label>
                                <input type="file" class="form-control" name="site_fav_icon" accept=".jpg,.jpeg,.png,.ico">
                                <?php if(!empty($setting->site_fav_icon)): ?>
                                    <div class="mt-2">
                                        <label class="text-muted">Current Favicon:</label><br>
                                        <img src="<?php echo e(asset('storage/'.$setting->site_fav_icon)); ?>" alt="Favicon" class="preview-img">
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <label>Copyright</label>
                                <input type="text" name="copyright" value="<?php echo e($setting->copyright ?? ''); ?>" class="form-control">
                            </div>

                        </div>
                    </div>
                </div>

                <div class="card-footer bg-light text-right">
                    <button type="submit" class="btn btn-success btn-sm" id="update_btn" accesskey="s">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\mayacomputer\resources\views/admin/cms/site_settings/edit.blade.php ENDPATH**/ ?>