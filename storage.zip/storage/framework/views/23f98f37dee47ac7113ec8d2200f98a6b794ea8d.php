
<?php $__env->startSection('title', 'Download Form List'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3" >
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Download Form List
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('add_download_form')); ?>">  <button class="btn btn-success btn-sm" > Add New Form</button></a>
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>ID</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>File</th>
                                <th>Actions</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	<?php $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($download->id); ?></td>
                                    <td><?php echo e($download->download_name); ?></td>
                                    <td><?php echo e($download->type); ?></td>
                                    <td>
										<a href="<?php echo e(asset($download->file)); ?>" target="_blank" class="badge bg-primary text-decoration-none">
											View
										</a>
									</td>
                                    <td>
                                        <a href="<?php echo e(route('edit_download_form', $download->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <a href="<?php echo e(route('delete_download_form', $download->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
	
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\mayacomputer\resources\views/admin/cms/downloads/index.blade.php ENDPATH**/ ?>